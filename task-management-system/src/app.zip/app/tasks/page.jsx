'use client';
import React, { useEffect, useState, useRef } from 'react'; // <--- Add useRef here
import { axiosClient } from '@/helper/helper';
import { TASKS, USERS, TASK_ASSIGN } from '@/helper/routes';
import Link from 'next/link';
import { toast } from 'react-toastify';

function Page() {
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({});
  const [tasks, setTasks] = useState([]);
  const [userId, setUserId] = useState('');
  const [taskId, setTaskId] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [modal, setModal] = useState();
  const [selectedFiles, setSelectedFiles] = useState([]); // State to hold newly selected files for upload
  const [existingFiles, setExistingFiles] = useState([]); // State to hold existing files from the task
  const [filesToRemove, setFilesToRemove] = useState([]); // State to hold file IDs to be removed
  const Priority = ['High', 'Mid', 'Low'];

  // Create a ref for the file input
  const fileInputRef = useRef(null); // <--- New ref

  const handleInput = (e) => {
    const fieldName = e.target.name;
    const fieldValue = e.target.value;
    setFormData((prevState) => ({
      ...prevState,
      [fieldName]: fieldValue,
    }));
  };

  const handleFileUpload = (e) => {
    const newFiles = Array.from(e.target.files);
    setSelectedFiles((prevFiles) => [...prevFiles, ...newFiles]);
  };

const handleRemoveExistingFile = (fileId) => {
    console.log("Removing file with ID:", fileId);
    setExistingFiles((prevFiles) => {
        const updated = prevFiles.filter((file) => file.id !== fileId);
        console.log("Previous files:", prevFiles);
        console.log("Updated files after filter:", updated);
        return updated;
    });
    setFilesToRemove((prevFilesToRemove) => [...prevFilesToRemove, fileId]);
};

  const handleRemoveNewFile = (fileName) => {
    setSelectedFiles((prevFiles) => prevFiles.filter((file) => file.name !== fileName));
    // Clear the file input field itself if all new files are removed (optional, but good UX)
    if (fileInputRef.current && selectedFiles.length === 1 && selectedFiles[0].name === fileName) {
      fileInputRef.current.value = '';
    }
  };

  const priorityMap = {
    1: 'high',
    2: 'mid',
    3: 'low',
  };

  const getUsers = async () => {
    let response = await axiosClient().get(USERS);
    if (response?.status === 200) {
      setUsers(response?.data?.data);
    }
  };

  // Helper function to reset form and file states
  const resetFormAndFiles = () => {
    setFormData({});
    setSelectedFiles([]);
    setExistingFiles([]);
    setFilesToRemove([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = ''; // Clear the file input field
    }
  };

  const addTask = async () => {
    const dataToSend = new FormData();

    for (const key in formData) {
      if (formData[key] !== undefined && formData[key] !== null) {
        dataToSend.append(key, formData[key]);
      }
    }

    selectedFiles.forEach((file) => {
      dataToSend.append('task_files[]', file);
    });

    try {
      let response = await axiosClient().post(TASKS, dataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      $('#rejectTraining').modal('toggle');

      if (response?.status === 200) {
        let res = await axiosClient().post(TASK_ASSIGN, {
          assigned_to: formData.assigned,
          task_id: response?.data?.data?.id,
        });

        if (res?.status === 200) {
          toast.success(res?.data?.message);
          getTasks();
          resetFormAndFiles(); // <--- Reset after success
        } else {
          toast.error(res?.data?.message || 'Task assignment failed.');
        }
      } else {
        toast.error(response?.data?.message || 'Task creation failed.');
      }
    } catch (error) {
      console.error('Error submitting task:', error);
      toast.error('An error occurred while creating the task.');
    }
  };

  const editTask = async () => {
    const dataToSend = new FormData();

    for (const key in formData) {
      if (formData[key] !== undefined && formData[key] !== null) {
        dataToSend.append(key, formData[key]);
      }
    }

    selectedFiles.forEach((file) => {
      dataToSend.append('task_files[]', file);
    });

    filesToRemove.forEach((fileId) => {
      dataToSend.append('files_to_remove[]', fileId);
    });

    dataToSend.append('_method', 'PUT'); // Laravel expects _method for PUT with FormData

    try {
      let response = await axiosClient().post(`${TASKS}/${taskId}`, dataToSend, { // Use POST for FormData with _method=PUT
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      $('#rejectTraining').modal('toggle');

      if (response?.status === 200) {
        // Re-assigning task if the assigned user has changed
        if (formData.assigned) {
          let res = await axiosClient().post(TASK_ASSIGN, {
            assigned_to: formData.assigned,
            task_id: taskId,
          });
          if (res?.status === 200) {
            toast.success(response?.data?.message); // Show success for task update
            getTasks();
            resetFormAndFiles(); // <--- Reset after success
          } else {
            toast.error(res?.data?.message || 'Task assignment update failed.');
          }
        } else {
          toast.success(response?.data?.message);
          getTasks();
          resetFormAndFiles(); // <--- Reset after success
        }
      } else {
        toast.error(response?.data?.message || 'Task update failed.');
      }
    } catch (error) {
      console.error('Error updating task:', error);
      toast.error('An error occurred while updating the task.');
    }
  };


  const getTasks = async () => {
    let response = await axiosClient().get(TASKS);
    if (response?.status === 200) {
      setTasks(response?.data?.data);
    }
  };

  const assignTask = async () => {
    let response = await axiosClient().post(TASK_ASSIGN, {
      assigned_to: userId,
      task_id: taskId,
    });
    $('#rejectTraining').modal('toggle');
    if (response?.status === 200) {
      toast.success(response?.data?.message);
      getTasks();
    }
  };

  const removeTask = async (id) => {
    let response = await axiosClient().delete(TASKS + '/' + id);
    if (response?.status === 200) {
      toast.success(response?.data?.message);
      getTasks();
    }
  };

  const getModalBody = () => {
    if (modal === 'assign') {
      return assignModal();
    } else if (modal === 'delete') {
      return deleteModal();
    } else if (modal === 'newTask') {
      return newTaskModal();
    } else if (modal === 'editTask') {
      return editTaskModal();
    }
  };

  const getFileIcon = (fileName) => {
    const extension = fileName?.split('.').pop().toLowerCase();
    switch (extension) {
      case 'pdf':
        return <i className="bx bxs-file-pdf" style={{ fontSize: '24px', color: 'red' }}></i>;
      case 'doc':
      case 'docx':
        return <i className="bx bxs-file-doc" style={{ fontSize: '24px', color: 'blue' }}></i>;
      case 'xls':
      case 'xlsx':
        return <i className="bx bxs-file-excel" style={{ fontSize: '24px', color: 'green' }}></i>;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return <i className="bx bxs-file-image" style={{ fontSize: '24px', color: 'purple' }}></i>;
      case 'zip':
      case 'rar':
        return <i className="bx bxs-file-archive" style={{ fontSize: '24px', color: 'orange' }}></i>;
      default:
        return <i className="bx bxs-file" style={{ fontSize: '24px', color: 'gray' }}></i>;
    }
  };

  const deleteModal = () => {
    return (
      <>
        <div className="text-center mb-4">
          <h3 className="role-title mb-2">Confirm Delete?</h3>
        </div>

        <div className="col-12 text-center mt-4">
          <button
            type="submit"
            className="btn btn-danger me-sm-3 me-1"
            data-bs-dismiss="modal"
            aria-label="Close"
            onClick={(e) => {
              e.preventDefault();
              setDeleteConfirm(true);
            }}
          >
            Delete
          </button>
          <button
            type="reset"
            className="btn btn-label-secondary"
            data-bs-dismiss="modal"
            aria-label="Close"
            onClick={(e) => {
              e.preventDefault();
              setDeleteConfirm(false);
            }}
          >
            Cancel
          </button>
        </div>
      </>
    );
  };

  const assignModal = () => {
    return (
      <>
        <div className="text-center mb-4">
          <h3 className="role-title mb-2">Assign Task</h3>
        </div>
        <form
          id="addRoleForm"
          className="row g-3"
          onSubmit={(e) => {
            e.preventDefault();
            assignTask();
          }}
        >
          <div className="col-12 mb-4">
            <label className="form-label" htmlFor="modalRoleName">
              Select User
            </label>
            <select
              id="assigned_to"
              className="select2 form-select select2-hidden-accessible"
              data-allow-clear="true"
              data-select2-id="assigned_to"
              tabIndex="-1"
              aria-hidden="true"
              name="assigned_to"
              onChange={(e) => setUserId(e.target.value)}
            >
              <option value="">Select User</option> {/* Added default option */}
              {users.map((value, i) => {
                return <option key={i} value={value.id}>{value?.name}</option>;
              })}
            </select>
          </div>

          <div className="col-12 text-center mt-4">
            <button type="submit" className="btn btn-primary me-sm-3 me-1">
              Submit
            </button>
            <button
              type="reset"
              className="btn btn-label-secondary"
              data-bs-dismiss="modal"
              aria-label="Close"
            >
              Cancel
            </button>
          </div>
        </form>
      </>
    );
  };

  const newTaskModal = () => {
    return (
      <>
        <div className="text-center mb-4">
          <h3 className="role-title mb-2">New Task</h3>
        </div>
        <form
          id="addRoleForm"
          className="row g-3"
          onSubmit={(e) => {
            e.preventDefault();
            addTask();
          }}
        >
          <div className="col-12 mb-4">
            <label htmlFor="title" className="form-label">
              Title
            </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Title"
              id="title"
              name="title"
              onChange={handleInput}
              value={formData.title || ''}
            />
          </div>
          <div className="col-12 mb-4">
            <label htmlFor="description" className="form-label">
              Description
            </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Description"
              id="description"
              name="description"
              onChange={handleInput}
              value={formData.description || ''}
            />
          </div>
          <div className="col-12 mb-4">
            <label htmlFor="deadline" className="form-label">
              Deadline
            </label>
            <input
              type="datetime-local"
              className="form-control"
              placeholder="Enter deadline"
              id="deadline"
              name="deadline"
              onChange={handleInput}
              value={formData.deadline || ''}
            />
          </div>
          <div className="col-12 mb-4">
            <label className="form-label" htmlFor="assigned">
              Assign User
            </label>
            <select
              id="assigned"
              className="select2 form-select select2-hidden-accessible"
              data-allow-clear="true"
              data-select2-id="assigned"
              tabIndex="-1"
              aria-hidden="true"
              name="assigned"
              onChange={handleInput}
              value={formData.assigned || ''}
            >
              <option value="">Select User</option>
              {users.map((value, i) => {
                return <option key={i} value={value.id}>{value?.name}</option>;
              })}
            </select>
          </div>
          <div className="col-12 mb-4">
            <label className="form-label" htmlFor="priority">
              Task Priority
            </label>
            <select
              id="priority"
              className="select2 form-select select2-hidden-accessible"
              data-allow-clear="true"
              data-select2-id="priority"
              tabIndex="-1"
              aria-hidden="true"
              name="priority"
              onChange={handleInput}
              value={formData.priority || ''}
            >
              <option value="">Select Priority</option>
              {Priority.map((value, i) => {
                return <option key={i} value={i + 1}>{value}</option>;
              })}
            </select>
          </div>

          <div className="col-12 mb-4">
            <label className="form-label" htmlFor="uploadFiles">
              Upload Files
            </label>
            <input
              type="file"
              id="uploadFiles"
              onChange={handleFileUpload}
              multiple
              className="form-control"
              ref={fileInputRef} 
            />
            <div className="mt-2">
              {selectedFiles.length > 0 && (
                <div>
                  <h6>New Files to Upload:</h6>
                  <ul className="list-unstyled">
                    {selectedFiles.map((file, index) => (
                      <li key={index} className="d-flex align-items-center mb-1 justify-content-between">
                        <div>
                          {getFileIcon(file.name)}
                          <span className="ms-2">{file.name}</span>
                        </div>
                        <button type="button" className="btn-close" aria-label="Remove" onClick={() => handleRemoveNewFile(file.name)}></button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          <div className="col-12 text-center mt-4">
            <button type="submit" className="btn btn-primary me-sm-3 me-1">
              Submit
            </button>
            <button
              type="reset"
              className="btn btn-label-secondary"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={resetFormAndFiles} // <--- Use reset function here
            >
              Cancel
            </button>
          </div>
        </form>
      </>
    );
  };

  const editTaskModal = () => {
    return (
      <>
        <div className="text-center mb-4">
          <h3 className="role-title mb-2">Edit Task</h3>
        </div>
        <form
          id="editTaskForm"
          className="row g-3"
          onSubmit={(e) => {
            e.preventDefault();
            editTask();
          }}
        >
          <div className="col-12 mb-4">
            <label htmlFor="title" className="form-label">
              Title
            </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Title"
              id="title"
              name="title"
              onChange={handleInput}
              value={formData.title || ''}
            />
          </div>
          <div className="col-12 mb-4">
            <label htmlFor="description" className="form-label">
              Description
            </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Description"
              id="description"
              name="description"
              onChange={handleInput}
              value={formData.description || ''}
            />
          </div>
          <div className="col-12 mb-4">
            <label htmlFor="deadline" className="form-label">
              Deadline
            </label>
            <input
              type="datetime-local"
              className="form-control"
              placeholder="Enter deadline"
              id="deadline"
              name="deadline"
              onChange={handleInput}
              value={formData.deadline || ''}
            />
          </div>
          <div className="col-12 mb-4">
            <label className="form-label" htmlFor="assigned">
              Assign User
            </label>
            <select
              id="assigned"
              className="select2 form-select select2-hidden-accessible"
              data-allow-clear="true"
              data-select2-id="assigned"
              tabIndex="-1"
              aria-hidden="true"
              name="assigned"
              onChange={handleInput}
              value={formData.assigned || ''}
            >
              <option value="">Select User</option>
              {users.map((value, i) => {
                return <option key={i} value={value.id}>{value?.name}</option>;
              })}
            </select>
          </div>
          <div className="col-12 mb-4">
            <label className="form-label" htmlFor="priority">
              Task Priority
            </label>
            <select
              id="priority"
              className="select2 form-select select2-hidden-accessible"
              data-allow-clear="true"
              data-select2-id="priority"
              tabIndex="-1"
              aria-hidden="true"
              name="priority"
              onChange={handleInput}
              value={formData.priority || ''}
            >
              <option value="">Select Priority</option>
              {Priority.map((value, i) => {
                return <option key={i} value={i + 1}>{value}</option>;
              })}
            </select>
          </div>

          <div className="col-12 mb-4">
            <label className="form-label" htmlFor="uploadFiles">
              Upload New Files
            </label>
            <input
              type="file"
              id="uploadFiles"
              onChange={handleFileUpload}
              multiple
              className="form-control"
              ref={fileInputRef}
            />
            <div className="mt-2">
                {existingFiles.length > 0 && (
                    <div>
                        <h6>Existing Files:</h6>
                        <ul className="list-unstyled">
                            {existingFiles.map((file) => (
                                <li key={file.id} className="d-flex align-items-center mb-1 justify-content-between">
                                    <div>
                                        {getFileIcon(file.original_name)}
                                        <a href={`${process.env.NEXT_PUBLIC_SERVER_URL}${file.stored_path}`} target="_blank" className="ms-2">
                                            {file.original_name}
                                        </a>
                                    </div>
                                    <button type="button" className="btn-close" aria-label="Remove" onClick={() => handleRemoveExistingFile(file.id)}></button>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
              {selectedFiles.length > 0 && (
                <div>
                  <h6>New Files to Upload:</h6>
                  <ul className="list-unstyled">
                    {selectedFiles.map((file, index) => (
                      <li key={index} className="d-flex align-items-center mb-1 justify-content-between">
                        <div>
                          {getFileIcon(file.name)}
                          <span className="ms-2">{file.name}</span>
                        </div>
                        <button type="button" className="btn-close" aria-label="Remove" onClick={() => handleRemoveNewFile(file.name)}></button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          <div className="col-12 text-center mt-4">
            <button type="submit" className="btn btn-primary me-sm-3 me-1">
              Save Changes
            </button>
            <button
              type="reset"
              className="btn btn-label-secondary"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={resetFormAndFiles} // <--- Use reset function here
            >
              Cancel
            </button>
          </div>
        </form>
      </>
    );
  };

  if (deleteConfirm) {
    removeTask(taskId);
    setDeleteConfirm(false);
  }

  useEffect(() => {
    getUsers();
    getTasks();
  }, []);

  return (
    <>
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div className="card mb-4 popular-product-card">
            <div className="card-body">
              <div className="common-fieldset-main">
                <fieldset className="common-fieldset">
                  <legend className="rounded">All Tasks</legend>
                  <div className="row">
                    <div className="col-12 text-end">
                      <div
                        className="btn btn-primary mb-4"
                        data-bs-target="#rejectTraining"
                        data-bs-toggle="modal"
                        onClick={() => {
                          setModal('newTask');
                          resetFormAndFiles(); // <--- Reset on opening Add Task modal
                        }}
                      >
                        Add Task
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="table-responsive">
                      <table className="table table-bordered card-datatable">
                        <thead className="border-bottom datatables">
                          <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Created By</th>
                            <th>Assigned To</th>
                            <th>Task Priority</th>
                            <th>Attachments</th>
                            <th>Deadline</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {tasks?.map((task, key) => {
                            const attachments = JSON.parse(task?.attachments || '[]');
                            const assignedUsers = task?.assigned?.map(user => user?.user?.name).join(', ') || 'N/A';
                            return (
                              <tr key={task.id || key}>
                                <td>{key + 1}</td>
                                <td>
                                  <small className="text-muted">
                                    {task?.title}
                                  </small>
                                </td>
                                <td>
                                  <small className="text-muted">
                                    {task?.description}
                                  </small>
                                </td>
                                <td>
                                  <small className="text-muted">
                                    {task?.assigned_by?.name}
                                  </small>
                                </td>
                                <td>
                                  <small className="text-muted">
                                    {assignedUsers}
                                  </small>
                                </td>
                                <td>
                                  <small className="text-muted">
                                    {priorityMap[task?.priority] || ''}
                                  </small>
                                </td>
                                <td>
                                  <small>
                                    <ul className="list-unstyled">
                                      {attachments.map((attachment, index) => (
                                        <li key={index} className="d-flex align-items-center mb-1">
                                          {getFileIcon(attachment.original_name)}
                                          <a href={`${process.env.NEXT_PUBLIC_SERVER_URL}${attachment.stored_path}`} target="_blank" className="ms-2">
                                            {attachment.original_name}
                                          </a>
                                        </li>
                                      ))}
                                    </ul>
                                  </small>
                                </td>

                                <td>
                                  <small>{task?.deadline}</small>
                                </td>
                                <td>
                                  <small>
                                    <button
                                      className="btn btn-primary btn-xs me-2"
                                      data-bs-target="#rejectTraining"
                                      data-bs-toggle="modal"
                                      onClick={() => {
                                        setModal('editTask');
                                        setTaskId(task?.id);
                                        setFormData({
                                          title: task?.title,
                                          description: task?.description,
                                          deadline: task?.deadline?.slice(0, 16), // Format for datetime-local input
                                          assigned: task?.assigned[0]?.user?.id || '', // Assuming single assigned user for simplicity
                                          priority: task?.priority || '',
                                        });
                                        setExistingFiles(attachments);
                                        setSelectedFiles([]);
                                        setFilesToRemove([]);
                                        if (fileInputRef.current) { // <--- Clear file input on edit click
                                            fileInputRef.current.value = '';
                                        }
                                      }}
                                    >
                                      Edit
                                    </button>
                                    <button
                                      className="btn btn-danger btn-xs me-2"
                                      data-bs-target="#rejectTraining"
                                      data-bs-toggle="modal"
                                      onClick={() => {
                                        setModal('delete');
                                        setTaskId(task?.id);
                                      }}
                                    >
                                      Delete
                                    </button>
                                    <button
                                      className="btn btn-info btn-xs" // Changed to info for distinction
                                      data-bs-target="#rejectTraining"
                                      data-bs-toggle="modal"
                                      onClick={() => {
                                        setModal('assign');
                                        setTaskId(task?.id);
                                        setUserId(''); // Clear previous selection
                                      }}
                                    >
                                      Re-Assign
                                    </button>
                                  </small>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </fieldset>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Modals */}
      <div
        className="modal fade"
        tabIndex="-1"
        id="rejectTraining"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-lg modal-dialog-centered modal-add-new-role">
          <div className="modal-content p-3 p-md-5">
            <button
              type="button"
              className="btn-close btn-pinned"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={resetFormAndFiles} // <--- Reset on modal close button
            ></button>
            <div className="modal-body">{getModalBody()}</div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Page;